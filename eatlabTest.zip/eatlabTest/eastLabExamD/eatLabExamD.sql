CREATE TABLE "customerPersonInformation" (
  "customerId" integer PRIMARY KEY,
  "customerName" varchar,
  "email" varchar,
  "shippingAddress" varchar
);

CREATE TABLE "product" (
  "productId" integer PRIMARY KEY,
  "productName" varchar,
  "productPrice" varchar,
  "productCategory" varchar
);

CREATE TABLE "inventoryQuantity" (
  "inventoryId" integer PRIMARY KEY,
  "amountProduct" integer,
  "productId" varchar
);

CREATE TABLE "shoppingcart" (
  "shoppingcartId" integer PRIMARY KEY,
  "productId" integer,
  "customerId" integer,
  "statusShoppingCart" varchar
);

CREATE TABLE "review" (
  "reviewId" integer,
  "customerId" integer,
  "productId" integer
);

CREATE TABLE "orderProduct" (
  "orderProductId" integer PRIMARY KEY,
  "productId" integer,
  "customerId" integer,
  "statusOrderProdcuct" varchar,
  "totalCast" integer,
  "created_at" timestamp
);

CREATE TABLE "orderProductDetail" (
  "orderProductDetailId" integer PRIMARY KEY,
  "productId" integer,
  "AmountOrderProduct" integer,
  "orderProductId" integer,
  "totalCast" integer
);

ALTER TABLE "shoppingcart" ADD FOREIGN KEY ("customerId") REFERENCES "customerPersonInformation" ("customerId");

ALTER TABLE "review" ADD FOREIGN KEY ("customerId") REFERENCES "customerPersonInformation" ("customerId");

ALTER TABLE "shoppingcart" ADD FOREIGN KEY ("productId") REFERENCES "product" ("productId");

ALTER TABLE "review" ADD FOREIGN KEY ("productId") REFERENCES "product" ("productId");

ALTER TABLE "orderProduct" ADD FOREIGN KEY ("productId") REFERENCES "product" ("productId");

ALTER TABLE "orderProduct" ADD FOREIGN KEY ("customerId") REFERENCES "customerPersonInformation" ("customerId");

ALTER TABLE "orderProductDetail" ADD FOREIGN KEY ("productId") REFERENCES "product" ("productId");
