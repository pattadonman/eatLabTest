
CREATE TABLE ProductCategoryIncome (
    idCategoryProduct int,
    productCategory varchar(255),
    revenue int
);

SELECT revenue From ProductIncome order by revenue DESC;