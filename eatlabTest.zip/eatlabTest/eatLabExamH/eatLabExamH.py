

listAvailableRoomProperties = []

