CREATE TABLE "course" (
  "uniqueIDCourse" integer PRIMARY KEY,
  "courseName" varchar,
  "descriptionName" varchar
);

CREATE TABLE "student" (
  "uniqueIDStudent" integer PRIMARY KEY,
  "studentName" varchar,
  "studentEmail" varchar,
  "graduationYear" integer
);

CREATE TABLE "enrollCourse" (
  "idEnrollCourse" integer PRIMARY KEY,
  "uniqueIDCourse" integer,
  "uniqueIDStudent" integer,
  "created_at" timestamp
);

ALTER TABLE "enrollCourse" ADD FOREIGN KEY ("uniqueIDStudent") REFERENCES "student" ("uniqueIDStudent");

ALTER TABLE "enrollCourse" ADD FOREIGN KEY ("uniqueIDCourse") REFERENCES "course" ("uniqueIDCourse");
