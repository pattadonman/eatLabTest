/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author pattadon
 */
interface Operation  {
  public float Addition(float value1,float value2); 
  public float Subtraction(float value1,float value2);
  public float Multiplication(float value1,float value2);
  public float Division(float value1,float value2);
}

class CalculatorFactory implements Operation{
    
    @Override
    public float Addition(float value1,float value2){
        float ans = 0;
        ans = value1 + value2;
        return ans;
    } 

    @Override
    public float Subtraction(float value1, float value2) {
        float ans = 0;
        ans = value1 - value2;
        return ans;
    }

    @Override
    public float Multiplication(float value1, float value2) {
        float ans = 0;
        ans = value1 * value2;
        return ans;
    }

    @Override
    public float Division(float value1, float value2) {
        float ans = 0;
        if(value2 > 0){
            ans = value1 / value2;
        }else{
            ans = 0;
            System.out.println("can not division");
        }
        return ans;
    }
}
public class Mavenproject2 {

    public static void main(String[] args) {
        CalculatorFactory obj = new CalculatorFactory();
        System.out.println(obj.Addition(1,2));
        System.out.println(obj.Subtraction(2,2));
        System.out.println(obj.Multiplication(1,2));
        System.out.println(obj.Division(2,2));
        System.out.println(obj.Division(2,0));
    }
}
