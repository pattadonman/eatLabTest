class Node1 {
  public key: number;
  left = null;
  right = null;

  public constructor(key: number) {
    this.key = key;
    this.left = null;
    this.right = null;
  }

}

let root = null;

function printPostorder(node:Node1): void {
    if(node == null){
        return;
    }
    printPostorder(node.left);
    printPostorder(node.right);
    console.log(node.key + " ");
}

function printInorder(node:Node1): void {
    if(node == null){
        return;
    }
    printPostorder(node.left);
    console.log(node.key + " ");
    printPostorder(node.right);
}

function printPreorder(node:Node1): void {
    if(node == null){
        return;
    }
    console.log(node.key + " ");
    printPostorder(node.left);
    printPostorder(node.right);
}


        root = new Node1(1);
        root.left = new Node1(2);
        root.right = new Node1(3);
        root.left.left = new Node1(4);
        root.left.right = new Node1(5);
        
        console.log("input process if 1 = Pre-order, 2 = Post-order, 3 = In-order ::: ")
        
        let chooseProcess: number[] = process.argv.slice(2);
        
        
        if(chooseProcess == 1){
            console.log("Pre-order Ouput:[");
            printPreorder(root);
            console.log("]");

        }else if(chooseProcess == 2){
            console.log("Post-order Ouput:[");
            printInorder(root);
            console.log("]");
        }else if(chooseProcess == 3){
            console.log("In-order Output:[");
            printPostorder(root);
            console.log("]");
        }else{
            console.log("error");
        }
        




        
