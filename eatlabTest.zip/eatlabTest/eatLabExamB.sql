
CREATE TABLE ProductCateGoryRating (
    idProduct int,
  	productName varchar(255),
    productCategoryName varchar(255),
  	productAverageRating int
);

SELECT productName , productCategoryName FROM ProductCateGoryRating order by DESC LIMIT 5;